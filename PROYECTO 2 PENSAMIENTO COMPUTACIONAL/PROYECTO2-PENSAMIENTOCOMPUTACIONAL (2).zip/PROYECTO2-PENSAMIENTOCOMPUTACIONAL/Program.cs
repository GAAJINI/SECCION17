﻿using System;
//GABRIEL ALEJANDRO AJIN IZAGGUIRE -- 1184924
namespace Sistema_Bancario
{
    //Clases de Transacciones
    class RegistroTransaccion
    {
        public DateTime FechaHora { get; set; }
        public decimal Monto { get; set; }
        public string Tipo { get; set; }

        public RegistroTransaccion(decimal monto, string tipo)
        {
            FechaHora = DateTime.Now;
            Monto = monto;
            Tipo = tipo;
        }
    }
    class Transacciones
    {
        public DateTime Dates { get; set; }
        public decimal MontoDinero { get; set; }
        public string Tipo { get; set; }

        public Transacciones(decimal montocash, string tipo)
        {
            Dates = DateTime.Now;
            MontoDinero = montocash;
            Tipo = tipo;
        }

        //Clases de Cuenta de Terceros
    }
    class CuentaTerceros
    {
        public string NombreUsuario { get; set; }
        public int NumeroCuenta_3 { get; set; }
        public string nombreBanco { get; set; }
        public string tipoMoneda_3 { get; set; }
        public decimal montoTransferir { get; set; }
        public int IDs { get; set; }

        public CuentaTerceros(int id, string nombre, int NCuenta, string nbanco, string tipMoneda, decimal montotransferido)
        {
            IDs = id;
            NombreUsuario = nombre;
            NumeroCuenta_3 = NCuenta;
            nombreBanco = nbanco;
            tipoMoneda_3 = tipMoneda;
            montoTransferir = montotransferido;
        }

    }
    class Program
    {
        //Aqui se invocaron a las 3 listas
        static List<RegistroTransaccion> transacciones = new List<RegistroTransaccion>();
        static List<CuentaTerceros> funciones3usuarios = new List<CuentaTerceros>();
        static List<Transacciones> Transaccioness = new List<Transacciones>();
        // Declaracion de Variables
        static int cuenta1 = 0;
        private static string Nombre;
        private static string TipodeCuentas;
        private static string TipodeMoneda;
        private static int DPI;
        private static int NumeroTelefonico;
        private static string Direccion;
        private static decimal saldoin;
        private static bool mostrarMenu;
        private static int numeroCuenta;
        private static string tip;
        private static int contadordelabono;
        private static int contadortiempo;

        static void Main(string[] args)
        {
            saldoin = 2500; // Saldo inicial de la cuenta
            ingresodatos();
            menu();
        }

        // INGRESO DE DATOS
        static void ingresodatos()
        {
            // INGRESO NOMBRE
            Console.WriteLine("DATOS DEL USUARIO\n");
            Console.WriteLine("Ingrese Su Nombre Completo");
            Nombre = Console.ReadLine();
            Console.WriteLine("");

            // INGRESO DE NUMERO DE CUENTA
            do
            {
                Console.WriteLine("Ingrese el Numero de Cuenta (8 digitos)");
                if (!int.TryParse(Console.ReadLine(), out numeroCuenta) || numeroCuenta.ToString().Length != 8)
                {
                    Console.WriteLine("Numero de Cuenta no Valido");
                }
            } while (numeroCuenta.ToString().Length != 8);
            Console.WriteLine("");

            // INGRESO DE DPI
            do
            {
                Console.WriteLine("Ingrese Su DPI (5 digitos):");
                if (!int.TryParse(Console.ReadLine(), out DPI) || DPI.ToString().Length != 5)
                {
                    Console.WriteLine("DPI NO VALIDO");
                }
            } while (DPI.ToString().Length != 5);
            Console.WriteLine("");

            // INGRESO DE TELEFONO
            do
            {
                Console.WriteLine("Ingrese Su Numero Telefonico (8 digitos)");
                if (!int.TryParse(Console.ReadLine(), out NumeroTelefonico) || NumeroTelefonico.ToString().Length != 8)
                {
                    Console.WriteLine("Numero de Telefono no Valido");
                }
            } while (NumeroTelefonico.ToString().Length != 8);
            Console.WriteLine("");

            //INGRESO DE TIPO DE CUENTA
            int TipodeCuenta = 0;
            do
            {
                Console.WriteLine("------------------");
                Console.WriteLine("Tipo de Cuenta");
                Console.WriteLine("1-MONETARIA");
                Console.WriteLine("2-AHORRO");
                Console.WriteLine("------------------");
                Console.WriteLine("Ingrese el valor del Tipo de Cuenta (1 o 2):");

                if (int.TryParse(Console.ReadLine(), out TipodeCuenta) && (TipodeCuenta == 1 || TipodeCuenta == 2))
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Dato no Valido. Por favor, ingrese 1 o 2.");
                }
            } while (true);

            // INGRESO TIPO DE MONEDA
            int TipodeMone = 0;
            do
            {
                Console.WriteLine("------------------");
                Console.WriteLine("Tipo de Moneda");
                Console.WriteLine("1-QUETZALES");
                Console.WriteLine("2-DOLARES");
                Console.WriteLine("------------------");
                Console.WriteLine("Ingrese el valor del Tipo de Moneda (1 o 2):");

                if (int.TryParse(Console.ReadLine(), out TipodeMone) && (TipodeMone == 1 || TipodeMone == 2))
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Dato no Valido. Por favor, ingrese 1 o 2.");
                }
            } while (true);
        }

        // MENU
        static void menu()
        {
            mostrarMenu = true;
            while (mostrarMenu)
            {
                Console.WriteLine("-------------------------------------");
                Console.WriteLine("MENU DE USUARIO\n");
                Console.WriteLine("1. VER INFORMACION DE LA CUENTA");
                Console.WriteLine("2. COMPRAR UN PRODUCTO FINANCIERO");
                Console.WriteLine("3. VENDER PRODUCTO FINANCIERO");
                Console.WriteLine("4. ABONAR A CUENTA");
                Console.WriteLine("5. SIMULAR PASO DEL TIEMPO");
                Console.WriteLine("6. REGISTRO DE TRANSACCIONES");
                Console.WriteLine("7. MANTENIMIENTO DE CUENTAS DE TERCEROS");
                Console.WriteLine("8. TRANSFERENCIAS A OTRAS CUENTAS");
                Console.WriteLine("9. PAGO DE SERVICIOS");
                Console.WriteLine("10. IMPRIMIR INFORME DE TRANSACCIONES");
                Console.WriteLine("11. SALIR");
                Console.WriteLine("-------------------------------------");
                Console.WriteLine("INGRESE LA OPCION QUE DESEA EFECTUAR");
                if (!int.TryParse(Console.ReadLine(), out int numero))
                {
                    Console.WriteLine("Por favor, ingrese un número válido.");
                    continue;
                }
                switch (numero)
                {
                    case 1:
                        InfoCuenta();
                        break;
                    case 2:
                        Comprar();
                        break;
                    case 3:
                        Vender();
                        break;
                    case 4 when contadordelabono < 3:
                        Abonar();
                        break;
                    case 5:
                        SimularTiempo();
                        break;
                    case 6:
                        Transacciones();
                        break;
                    case 7:
                        CuentasTerceros();
                        break;
                    case 8:
                        Transferencias();
                        break;
                    case 9:
                        PagoSevicios();
                        break;
                    case 10:
                        Informe();
                        break;
                    case 11:
                        Console.WriteLine("GRACIAS POR SU PREFERENCIA!");
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("La opción seleccionada no es válida o se ha realizado la cantidad maxima permitida para este mes.");
                        break;
                }
            }
        }

        public static void InfoCuenta()
        {
            Console.WriteLine("-------------------------------------");
            Console.WriteLine("VER INFORMACION DE LA CUENTA");
            Console.WriteLine($"Numero de Cuenta {numeroCuenta}");
            Console.WriteLine($"Nombre: {Nombre}");
            Console.WriteLine($"DPI: {DPI}");
            Console.WriteLine($"Numero Telefonico: {NumeroTelefonico} ");
            Console.WriteLine($"Direccion: {Direccion} ");
            Console.WriteLine($"Tipo de Cuenta: {TipodeCuentas}");
            Console.WriteLine($"Tipo de Moneda: {TipodeMoneda}");
            Console.WriteLine($"Su saldo es de:  {saldoin} {TipodeMoneda}");
            Console.WriteLine("-------------------------------------");

            Console.ReadKey();
            Console.Clear();
        }
        public static void Comprar()
        {


            decimal descuento = 0.1m;
            decimal resultado = 0.0m;
            decimal totaln = 0.0m;

            Console.WriteLine("-------------------------------------");
            Console.WriteLine("COMPRA DE PRODUCTO FINANCIERO");
            Console.WriteLine("Desea realizar una compra?");
            Console.WriteLine("Ingresar 'Y/y' para si o 'N/n' para no");
            Console.WriteLine("-------------------------------------");

            char opcion2 = Console.ReadLine().ToLower()[0];
            // VARIABLES EN DECIMAL PARA PODER OPERAR DECIMALES

            if (opcion2 == 'y')
            {
                // RESULTADO DE LA OPERACION
                resultado = saldoin * descuento;
                totaln = saldoin - resultado;
                // SE GUARDA EL RESULTADO EN LA VARIABLE DE LA CUENTA INICIAL PARA PODER REEMPLAZAR VALORES
                saldoin = totaln;
                Console.WriteLine("Su compra se realizo con exito!!!");
                Console.WriteLine($"Su saldo actual es de {saldoin}");
                Console.WriteLine("-------------------------------------");
                transacciones.Add(new RegistroTransaccion(saldoin, "crédito"));
                Transaccioness.Add(new Transacciones(saldoin, "credito"));
                Console.ReadKey();
                Console.Clear();
            }
            else if (opcion2 == 'n')
            {
                Console.ReadKey();
                Console.Clear();
            }
        }
        public static void Vender()
        {
            decimal aumento = 0.11m;
            decimal resultado = 0.0m;
            decimal totaln = 0.0m;

            if (saldoin >= 500)
            {
                Console.WriteLine("-------------------------------------");
                Console.WriteLine("VENTA DE PRODUCTO FINANCIERO");
                Console.WriteLine("Desea realizar una venta?");
                Console.WriteLine("Ingresar 'Y/y' para si o 'N/n' para no");
                Console.WriteLine("-------------------------------------");

                char opcion2 = Console.ReadLine().ToLower()[0];

                if (opcion2 == 'y')
                {
                    // RESULTADO DE LA OPERACION
                    resultado = saldoin * aumento;
                    totaln = saldoin + resultado;
                    // SE GUARDA EL RESULTADO EN LA VARIABLE DE LA CUENTA INICIAL PARA PODER REEMPLAZAR VALORES
                    saldoin = totaln;
                    Console.WriteLine("Su venta se realizo con exito!!!");
                    Console.WriteLine($"Su saldo actual es de {saldoin}");
                    Console.WriteLine("-------------------------------------");
                    transacciones.Add(new RegistroTransaccion(saldoin, "debito"));
                    Transaccioness.Add(new Transacciones(saldoin, "debito"));
                    Console.ReadKey();
                    Console.Clear();
                }
                else if (opcion2 == 'n')
                {
                    Console.ReadKey();
                    Console.Clear();
                }
            }
            else
            {
                Console.WriteLine($"El saldo debe de ser mayor de 500 {TipodeMoneda}");
            }
        }
        public static void Abonar()
        {
            contadordelabono++;
            if (saldoin >= 500)
            {
                Console.WriteLine($"Saldo actual: ${saldoin}");
                Console.WriteLine("¿Deseas duplicar tu saldo actual?");
                Console.WriteLine("Ingresar 'Y/y' para sí o 'N/n' para no");
                char opcionAbono = Console.ReadLine().ToLower()[0];

                if (opcionAbono == 'y')
                {
                    saldoin *= 2; // Multiplicar el saldo actual por 2
                    contadordelabono++; // Incrementar el contador de abonos
                    Console.WriteLine($"Abono realizado. Nuevo saldo: ${saldoin}");
                    transacciones.Add(new RegistroTransaccion(saldoin, "Abono"));
                    Transaccioness.Add(new Transacciones(saldoin, "Abono"));
                    Console.ReadKey();
                    Console.Clear();
                }
                else if (opcionAbono == 'n')
                {
                    Console.WriteLine("Operación cancelada.");
                    Console.Clear();
                }
                else
                {
                    Console.WriteLine("Entrada inválida. Inténtalo nuevamente.");
                    Console.Clear();
                }
            }
            else
            {
                Console.WriteLine("El saldo debe ser mayor o igual a 500.");
                Console.Clear();
            }
        }
        public static void SimularTiempo()

        {
            contadortiempo += 30; // Simulando paso de 30 días (un mes)
            Console.WriteLine($"Han pasado: {contadortiempo} días");

            Console.WriteLine("Seleccione el periodo de capitalizacion que desea utilizar:");
            Console.WriteLine("1 - Una vez al mes");
            Console.WriteLine("2 - Dos veces al mes");
            int opcion;
            while (!int.TryParse(Console.ReadLine(), out opcion) || (opcion != 1 && opcion != 2))
            {
                Console.WriteLine("Opcion no valida. Por favor, intente nuevamente.");
            }

            decimal tasaInteres = 0.02m; // Tasa de Interes mensual
            decimal interesSimple = 0.0m;

            if (opcion == 1)
            {
                interesSimple = CalcularInteresSimple(saldoin, tasaInteres, contadortiempo / 30, 1); // Una vez al mes
                Transaccioness.Add(new Transacciones(saldoin, "Simulacion del Tiempo"));
            }
            else if (opcion == 2)
            {
                interesSimple = CalcularInteresSimple(saldoin, tasaInteres, (contadortiempo / 30) * 2, 1); // Dos veces al mes
                Transaccioness.Add(new Transacciones(saldoin, "Simulacion del Tiempo"));
            }

            saldoin += interesSimple;
            Console.WriteLine($"El interes simple acumulado es de: {interesSimple}");
            Console.WriteLine($"Su nuevo saldo es: {saldoin}");
            Console.ReadKey();
            Console.Clear();
        }
        public static void Transacciones()
        {
            Console.WriteLine("Listado de transacciones:");
            foreach (var cantidad in transacciones)
            {
                Console.WriteLine($"Fecha: {cantidad.FechaHora.ToShortDateString()}, Hora: {cantidad.FechaHora.ToShortTimeString()}, Monto: {cantidad.Monto}, Tipo: {cantidad.Tipo}");
            }
        }
        public static void CuentasTerceros()
        {
            Console.WriteLine("Cuentas de Terceros");
            Console.WriteLine("1-Crear Cuenta");
            Console.WriteLine("2-Eliminar Cuenta");

            int cuentas;
            do
            {
                Console.WriteLine("¿Que desea efectuar?");
                if (!int.TryParse(Console.ReadLine(), out cuentas))
                {
                    Console.WriteLine("Dato no Valido");
                }
            } while (cuentas.ToString().Length != 1);
            Console.WriteLine("");

            switch (cuentas)
            {
                case 1:
                    //CREACION DE LA CUENTA
                    Console.WriteLine("Creación de nueva cuenta de tercero:");
                    //SOLICITUD DE DATOS
                    int ID;
                    do
                    {
                        Console.WriteLine("Ingrese el ID:");
                        if (!int.TryParse(Console.ReadLine(), out ID))
                        {
                            Console.WriteLine("Numero de Telefono no Valido");
                        }
                    } while (ID.ToString().Length != 1);
                    Console.WriteLine("");

                    Console.WriteLine("Ingrese el nombre del Propietario:");
                    string nombre = Console.ReadLine();

                    Console.WriteLine("Ingrese el número de cuenta del tercero (8 dígitos):");
                    int numeroCuenta_3;
                    while (!int.TryParse(Console.ReadLine(), out numeroCuenta_3) || numeroCuenta_3.ToString().Length != 8)
                    {
                        Console.WriteLine("Número de cuenta no válido. Debe ser de 8 dígitos.");
                    }

                    Console.WriteLine("Ingrese el nombre del banco:");
                    string nombreBanco = Console.ReadLine();
                    Console.WriteLine("Ingrese el tipo de moneda:");
                    string tipoMoneda_3 = Console.ReadLine();
                    decimal montoTransferir;

                    //LLAMADA DE LOS DATOS
                    CuentaTerceros nuevaCuenta = new CuentaTerceros(ID, nombre, numeroCuenta_3, nombreBanco, tipoMoneda_3, 0);
                    //AGREGAR LA NUEVA CUENTDA
                    funciones3usuarios.Add(nuevaCuenta);
                    Transaccioness.Add(new Transacciones(saldoin, "Creacion de Cuenta"));
                    Console.WriteLine("Cuenta de tercero creada exitosamente.");
                    Console.ReadKey();
                    Console.Clear();
                    break;


                case 2:
                    //BORRAR CUENTA
                    Console.WriteLine("Eliminar cuenta de tercero:");
                    Console.WriteLine("Ingrese el ID de la cuenta a eliminar:");

                    if (int.TryParse(Console.ReadLine(), out int id))
                    {
                        CuentaTerceros cuenta = funciones3usuarios.Find(c => c.IDs == id);
                        if (cuenta != null)
                        {
                            Transaccioness.Add(new Transacciones(saldoin, "Eliminacion de Cuenta"));
                            funciones3usuarios.Remove(cuenta);
                            Console.WriteLine("Cuenta de tercero eliminada exitosamente.");
                        }
                        else
                        {
                            Console.WriteLine("Cuenta no encontrada.");
                        }
                    }
                    else
                    {
                        Console.WriteLine("ID no válido.");
                    }
                    Console.ReadKey();
                    Console.Clear();
                    break;

            }

        }
        public static void Transferencias()
        {
            Console.WriteLine("Listado de Cuentas:");
            foreach (var func in funciones3usuarios)
            {
                Console.WriteLine($"ID: {func.IDs}, Nombre: {func.NombreUsuario}, Tipo de Moneda {func.tipoMoneda_3}, Numero de Cuenta: {func.NumeroCuenta_3}, Banco{func.nombreBanco}");
            }

            Console.WriteLine("Ingrese el ID de la cuenta a la que desea transferir:");

            if (int.TryParse(Console.ReadLine(), out int id))
            {

                CuentaTerceros cuenta = funciones3usuarios.Find(c => c.IDs == id);
                if (cuenta != null)
                {
                    Console.WriteLine($"Desea transferir a la cuenta seleccionada");
                    Console.WriteLine("Ingresar 'Y/y' para si o 'N/n' para no");
                    Console.WriteLine("-------------------------------------");

                    char opcion2 = Console.ReadLine().ToLower()[0];
                    // VARIABLES EN DECIMAL PARA PODER OPERAR DECIMALES

                    if (opcion2 == 'y')
                    {
                        Console.WriteLine("Ingresa la cantidad a depositar");
                        decimal montoatransferir = 0.0m;
                        if (!decimal.TryParse(Console.ReadLine(), out montoatransferir) || montoatransferir < 200 || montoatransferir > 2000)
                        {
                            Console.WriteLine("Cantidad no valida");
                        }
                        else
                        {

                            decimal restadetransferencia;
                            restadetransferencia = saldoin - montoatransferir;
                            saldoin = restadetransferencia;
                            Transaccioness.Add(new Transacciones(saldoin, "Transferencias"));
                            Console.WriteLine($"Se depositaron {montoatransferir} a la cuenta");
                            Console.ReadKey();
                            Console.Clear();
                        }



                    }
                    else if (opcion2 == 'n')
                    {
                        Console.ReadKey();
                        Console.Clear();
                    }
                }
                else
                {
                    Console.WriteLine("Cuenta no encontrada.");
                }
            }
            else
            {
                Console.WriteLine("ID no válido.");
            }
            Console.ReadKey();
            Console.Clear();

        }
        public static void PagoSevicios()
        {
            Console.WriteLine("Pago de Servicios");
            Console.WriteLine("1 - Empresa de agua");
            Console.WriteLine("2 - Empresa Eléctrica");
            Console.WriteLine("3 - Empresa Telefónica");

            int pago;
            do
            {
                Console.WriteLine("¿Qué servicio desea pagar?");
                if (!int.TryParse(Console.ReadLine(), out pago) || pago < 1 || pago > 3)
                {
                    Console.WriteLine("Dato no válido");
                }
            } while (pago < 1 || pago > 3);

            string empresa = "";
            if (pago == 1)
            {
                empresa = "Empresa de agua";
            }
            else if (pago == 2)
            {
                empresa = "Empresa Eléctrica";
            }
            else if (pago == 3)
            {
                empresa = "Empresa Telefónica";
            }
            else
            {
                throw new InvalidOperationException("Opción inválida");
            }

            Console.WriteLine($"Desea pagar a {empresa}");
            Console.WriteLine("Ingresar 'Y/y' para sí o 'N/n' para no");

            char opcion = Console.ReadLine().ToLower()[0];
            if (opcion == 'y')
            {
                Console.WriteLine("Ingrese el monto que desea pagar");
                if (decimal.TryParse(Console.ReadLine(), out decimal montoapagar))
                {
                    if (montoapagar > 0 && montoapagar <= saldoin)
                    {
                        saldoin -= montoapagar; // Resta el monto a pagar del saldo
                        Console.WriteLine($"Se pagaron {montoapagar} a {empresa}");
                        Transaccioness.Add(new Transacciones(montoapagar, $"Pago de {empresa}"));
                    }
                    else
                    {
                        Console.WriteLine("Monto no válido o saldo insuficiente");
                    }
                }
                else
                {
                    Console.WriteLine("Cantidad no válida");
                }
            }
            Console.ReadKey();
            Console.Clear();
        }


        public static void Informe()
        {
            Console.WriteLine("Informe General:");
            //Llamar a la lista/album por medio de foreach
            foreach (var cantidad in Transaccioness)
            {
                //Imprimir registros
                Console.WriteLine($"Fecha: {cantidad.Dates.ToShortDateString()}, Hora: {cantidad.Dates.ToShortTimeString()}, Monto: {cantidad.MontoDinero}, Tipo: {cantidad.Tipo}");
                Console.ReadKey();
                Console.Clear();
            }

        }
        public static decimal CalcularInteresSimple(decimal capital, decimal tasa, int tiempo, int periodo)
        {
            return capital * tasa * tiempo / periodo;
        }
    }
}



