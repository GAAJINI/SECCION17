﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace L4_PRACTICA_GABRIEL_AJIN_1184924
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int a = 0;
            int b = 1;
            int acm = 0;
            int n= int.Parse(textBox1.Text);
            int resultado;
            string fibo="";

            if (n>0) {
                    while(acm<n) {

                    resultado = b + a;
                    a = b;
                    b=resultado;
                    acm++;  
                    
                    fibo=resultado.ToString();
                    label3.Text = fibo;
                    
                }
                            
            }
            
            else if (n<0) {
                MessageBox.Show("EL VALOR ES INCORRECTO", "INGRESE UN VALOR MAYOR QUE 0");
            }
            

        }
    }
}
