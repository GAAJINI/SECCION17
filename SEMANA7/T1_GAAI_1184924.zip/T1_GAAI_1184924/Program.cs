﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Mi Segundo Programa");

string sNombre, sEdad, sCarrera, sCarne;

Console.WriteLine("Ingrese su Nombre");
sNombre= Console.ReadLine();

Console.WriteLine("Ingrese su Edad");
sEdad= Console.ReadLine();

Console.WriteLine("Ingrese su Carrera");
sCarrera= Console.ReadLine();

Console.WriteLine("Ingrese su Carnet");
sCarne= Console.ReadLine();

Console.WriteLine();
Console.WriteLine("Soy "+sNombre+" tengo "+sEdad+" años y estudio la carrera de "+sCarrera+" Mi numero de carne es: "+sCarne);

Console.ReadKey();
